# Event Hubs Demo

#### EventHubsSenderConApp

- Packages
  - Install-Package Azure.Messaging.EventHubs


#### EventHubsReceiverConApp
- Packages
  - Install-Package Azure.Messaging.EventHubs
  - Install-Package Azure.Messaging.EventHubs.Processor
- Will require a storage account
