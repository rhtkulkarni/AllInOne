# Service Bus Topic and Subscription

Project SBSendTopicConApp
	References
		1. System.Configuration
	Nuget Packages
		1. Install-Package Newtonsoft.Json (-Version 12.0.2)
		2. Install-Package WindowsAzure.ServiceBus (-Version 5.2.0)
		3. Install-package Microsoft.WindowsAzure.ConfigurationManager (-Version 3.2.3)
		

Project SBReceiveTopicConApp
	References
		1. System.Configuration
	Nuget Packages
		1. Install-Package WindowsAzure.ServiceBus (-Version 5.2.0)
		2. Install-package Microsoft.WindowsAzure.ConfigurationManager (-Version 3.2.3)