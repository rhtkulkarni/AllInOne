# Service Bus Queue

- Projects
  - SBSendQueueConApp
    - Reference
      - System.Configuration
    - Nuget Packages
      - Install-Package Newtonsoft.json (-Version 12.0.2)
      - Install-Package WindowsAzure.ServiceBus (-Version 5.2.0)
      - Install-Package Microsoft.WindowsAzure.ConfigurationManager (-Version 3.2.3)

  - SBReceiveQueueConApp
    - Reference
      - System.Configuration
    - Nuget Packages
      - Install-Package WindowsAzure.ServiceBus (-Version 5.2.0)
      - Install-Package Microsoft.WindowsAzure.ConfigurationManager (-Version 3.2.3)